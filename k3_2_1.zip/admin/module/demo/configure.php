<?php
// check admin level
// unfortunately you have to make configurator manually, see qe_config for example
admin_check('3');

$txt['main_body'] = 'This is configure. If your module doesn\'t need a configuration, simply remove this file!';

<?php
// Use this file if you want to use custom installation, otherwise qE2 will use its own module installation process based on ini.xml.
// Using qE2 installation, means you only need to supply sql queries, tell what folders & files to create.
admin_check(4);		// security check
echo 'This is custom install';

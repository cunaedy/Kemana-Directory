<?php
// part of qEngine
require './../includes/admin_init.php';

kick_user('adm');

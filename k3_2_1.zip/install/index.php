<html>

<head>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../skins/_common/default.css"/>
<title>Kemana: Installation</title>
</head>

<body>
	<div class="container" style="margin-top:20px">
	<form method="get" action="install.php">
		<input type="hidden" name="cmd" value="new" id="new" checked="checked" />
		<div class="jumbotron">
			<h1 align="center">Welcome</h1>
			<p>Welcome to Kemana v3.2 (build 2017.09.09) installation!</p>
			<p>Step 1: Type of instalation.</p>

			<p><button type="submit" class="btn btn-primary btn-lg">New Installation</button></p>
			<small>Learn more about this script, <a href="http://www.c97.net">click here</a>.</small>
		</div>
	</form>
	</div>
</body>

</html>